footerYear.innerHTML = new Date().getFullYear();
