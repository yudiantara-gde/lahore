// Activating WOW.js Library For On Scroll Animation
new WOW().init();
