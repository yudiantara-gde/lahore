const footerForm = document.querySelector("footer form");
footerForm.addEventListener("submit", (e) => e.preventDefault());
